# 当前分支检查与修复

检查基线：yiyi-cs/IDP，Blink-Detection，1bd8a22edb19ba0a54a97a5eb2f02914287e44de。
这个压缩包是基于该提交的修复版；尚未 push 到 GitHub。

## 安装

把包内 Skripte 合并到项目根目录下的同名目录，允许覆盖文件。
不要先删除原目录；本包没有模型权重、视频、ASC 和你的其他数据。
本包提供完整 Python 文件树，避免之前因只替换部分目录导致核心文件丢失。
changes.patch 是同一组修改的另一种安装方式，不需要再重复应用。

## 检查发现并修正的问题

1. 两个校准脚本失败后可能仍以 0 退出；现在失败明确退出，主流程立刻验证实际输出。
2. PTGaze 比较模式缺同步 CSV 时会退回未同步输入；现已禁止。
3. PTGaze 可能优先挑 Run 中较新的旧 PKL；现在显式选择的 PKL 优先。
4. 全无效样本会在 min/max 时崩溃；现提前报告输入无效。
5. 两份 PDF 中 EyeLink 屏幕中心、无效样本、blink 阴影边界及横轴时长不完全一致；现统一。
6. ROI 解码失败曾只显示 Frame unavailable；现明确失败，不能作为成功产物。
7. ROI 与核心精确窗口都锁定第一个视频流并按绝对 PTS 定位。
8. blink 范围扫描不再使用 VFR 帧号 seek；顺序跳过，解码中断直接失败。
9. 显式缓存复制额外核对 FPS、校准模式等条件；同步与比较缓存还核对方法选择。
10. CLI 脚本目录改成按自身路径定位，不再依赖写死的用户目录。
11. 新增启动检查，实际解码一帧、初始化所选模型并调用一次推理，提前检查后续 PDF/数值依赖。
12. 集成 EyeLink 流程在启动前要求模式 2 以及所需 PKL；Step 10 在完整 blink 推理前核对整份 gaze 的真实帧时钟。

## Lanczos 与算法边界

生产配置只允许 none，处理函数返回原始帧，不放大。
非 none 模式和旧/不明图像时钟缓存被拒绝。
测试中的 lanczos_2x 字符串仅用于确认拒绝旧模式。
shared_blink_detection.py、shared_pupil_detection.py 与 fixation_detector.py 没有修改。
没有调整同步 offset、blink 阈值或 I-DT/P75 参数去追求旧图的一致外观。

## 实际完成的验证

- 31 项回归通过，包含真实调用两个校准 CLI，而不只是检查源码。
- 生成 FFV1、H.264 变帧率视频，包含 B 帧、非零起始 PTS；取出的帧与顺序解码逐像素一致。
- Step 10 合成集成测试通过：真实 fixation 核心、EyeLink 采样、统计和两份 PDF 运行；推理、ASC 导出和 ROI 图像使用测试夹具。
- 两份合成 PDF 已渲染并检查。
- 全部 Python 语法编译及 diff 格式检查通过。

## 仍未完成的验收

当前环境缺少 OpenCV、MediaPipe、librosa、beo7 原始视频和模型资产。
因此这里没有实际完成模型启动检查，也没有完成新的 beo7 原尺寸完整推理。
31 项测试通过不能证明新的 beo7 数值结果已经验收，不能承诺整条流水线绝不会出错。
旧 CSV 的帧号身份有歧义，不能靠改时间戳或重新打标签当成新 raw-frame 结果。

## 开跑前

在本机项目 Skripte 目录执行：

```bash
python -m shared.pipeline_preflight --video /Volumes/Empra9/Videos_60/beo7.mp4 --methods both
```

主 pipeline 也会自动执行同一检查。这个命令会加载真实模型并推理一帧，不会跑完整视频。
检查通过后，继续原有 master_cli.py 的模式 2，新建 Run。
建议首先用新 Run 核对至少一个 trial 的 gaze、blink、fixation 和 ROI，再进行批量运行。
